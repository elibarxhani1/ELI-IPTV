"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Menu, ChevronLeft, ChevronRight, CheckCircle, Users, PhoneIcon as WhatsappIcon } from "lucide-react"
import { LanguageSelector } from "@/components/LanguageSelector"
import { LiveVisitorCounter } from "@/components/LiveVisitorCounter"
import { ServerCard } from "@/components/ServerCard"
import Slider from "react-slick"

const serverOptions = [
  { name: "TREX and Strong8K", price: "55€" },
  { name: "Tivione and Magnum", price: "55€" },
  { name: "Dino and Diamond", price: "55€" },
  { name: "4Kott and Cobra", price: "55€" },
  { name: "Livego and Crystal", price: "55€" },
  { name: "Lion and Mega", price: "55€" },
]

const translations = {
  en: {
    title: "Eli IPTV World",
    subtitle: "Experience the Best in IPTV Streaming",
    experience: "Enjoy HD, 4K, and 8K quality streaming on all your devices",
    pricing: "Pricing",
    about: "About",
    contact: "Contact",
    days: "days",
    buyWithStripe: "Buy with Stripe",
    payWithPaypal: "Pay with PayPal",
    additionalFeatures: "Why Choose Us",
    moneyBackGuarantee: "Money-Back Guarantee",
    clients: "Happy Clients",
    support: "24/7 Support",
    faq: "Frequently Asked Questions",
    receiveSubscription: "How do I receive my subscription?",
    receiveAnswer:
      "After your payment is confirmed, you will receive an email with your subscription details and instructions on how to set up your IPTV service.",
    supportedDevices: "What devices are supported?",
    supportedDevicesAnswer:
      "Our IPTV service supports a wide range of devices including Smart TVs, Android boxes, iOS and Android mobile devices, MAG boxes, and more.",
    connections: "How many connections do I get?",
    connectionsAnswer:
      "Each subscription comes with 1 connection by default. You can upgrade to multiple connections if needed.",
    adultContent: "Is adult content included?",
    adultContentAnswer:
      "Adult content is available as an optional add-on. It is not included in the standard package and can be enabled upon request.",
    internetSpeed: "What internet speed do I need?",
    internetSpeedAnswer:
      "For the best streaming experience, we recommend a minimum internet speed of 25 Mbps for HD content and 50 Mbps for 4K content.",
    refund: "What is your refund policy?",
    refundAnswer:
      "We offer a 7-day money-back guarantee. If you're not satisfied with our service, you can request a full refund within 7 days of your purchase.",
    contactUs: "Contact Us on WhatsApp",
    footer: "© 2023 Eli IPTV World. All rights reserved.",
    aboutEliIPTV: "About Eli IPTV World",
    aboutContent1: "Eli IPTV World is your premier destination for high-quality IPTV streaming services.",
    aboutContent2: "We offer a vast selection of channels and on-demand content from around the globe.",
    aboutContent3:
      "Our service is designed to provide you with the best possible viewing experience on all your devices.",
    aboutContent4:
      "With our reliable streams and 24/7 customer support, you'll never miss a moment of your favorite shows.",
    aboutContent5: "Choose Eli IPTV World for unparalleled entertainment at your fingertips.",
  },
  // Add other languages here as needed
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [currentLanguage, setCurrentLanguage] = useState("en")
  const [isHeaderVisible, setIsHeaderVisible] = useState(true)
  const subscriptionRef = useRef<HTMLDivElement>(null)
  const aboutRef = useRef<HTMLDivElement>(null)
  const contactRef = useRef<HTMLDivElement>(null)
  const receiveRef = useRef<HTMLDivElement>(null)
  const adultContentRef = useRef<HTMLDivElement>(null)
  const internetSpeedRef = useRef<HTMLDivElement>(null)
  const sliderRef = useRef<Slider>(null)

  const t = translations[currentLanguage as keyof typeof translations]

  useEffect(() => {
    let lastScrollY = window.pageYOffset
    const handleScroll = () => {
      const currentScrollY = window.pageYOffset
      setIsHeaderVisible(currentScrollY <= lastScrollY)
      lastScrollY = currentScrollY
    }
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (ref: React.RefObject<HTMLDivElement>) => {
    if (ref.current) {
      const yOffset = -80
      const y = ref.current.getBoundingClientRect().top + window.pageYOffset + yOffset
      window.scrollTo({ top: y, behavior: "smooth" })
    }
    setMenuOpen(false)
    setMobileMenuOpen(false)
  }

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  }

  return (
    <div className="min-h-screen relative bg-gradient-to-b from-[#1a1a1a] to-[#000000]">
      {/* Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 p-4 flex justify-between items-center transition-transform duration-300 ${
          isHeaderVisible ? "translate-y-0" : "-translate-y-full"
        }`}
      >
        <div className="w-2/3 flex justify-between">
          <a href="/" className="text-3xl font-bold text-white">
            {t.title}
          </a>
          <Menu onClick={() => setMenuOpen(!menuOpen)} className="lg:hidden w-6 h-6 text-white cursor-pointer" />
        </div>
        <div className="w-1/3 flex justify-end items-center">
          <LanguageSelector currentLanguage={currentLanguage} onLanguageChange={setCurrentLanguage} />
          <LiveVisitorCounter />
        </div>
      </header>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="fixed top-0 left-0 right-0 bottom-0 bg-black/50 z-50">
          <div className="bg-black/20 p-4 w-full h-full flex flex-col justify-center items-center">
            <div className="flex justify-end w-full mb-4">
              <ChevronLeft onClick={() => setMobileMenuOpen(false)} className="w-6 h-6 text-white cursor-pointer" />
            </div>
            <ul className="flex flex-col gap-4">
              <li
                onClick={() => scrollToSection(subscriptionRef)}
                className="text-xl font-medium text-white cursor-pointer"
              >
                {t.pricing}
              </li>
              <li onClick={() => scrollToSection(aboutRef)} className="text-xl font-medium text-white cursor-pointer">
                {t.about}
              </li>
              <li onClick={() => scrollToSection(contactRef)} className="text-xl font-medium text-white cursor-pointer">
                {t.contact}
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* Menu */}
      {menuOpen && (
        <div className="fixed top-0 left-0 right-0 bottom-0 bg-black/50 z-50 hidden lg:block">
          <div className="bg-black/20 p-4 w-1/2 h-full flex flex-col justify-center items-center">
            <div className="flex justify-end w-full mb-4">
              <ChevronLeft onClick={() => setMenuOpen(false)} className="w-6 h-6 text-white cursor-pointer" />
            </div>
            <ul className="flex flex-col gap-4">
              <li
                onClick={() => scrollToSection(subscriptionRef)}
                className="text-xl font-medium text-white cursor-pointer"
              >
                {t.pricing}
              </li>
              <li onClick={() => scrollToSection(aboutRef)} className="text-xl font-medium text-white cursor-pointer">
                {t.about}
              </li>
              <li onClick={() => scrollToSection(contactRef)} className="text-xl font-medium text-white cursor-pointer">
                {t.contact}
              </li>
            </ul>
          </div>
        </div>
      )}

      <main className="mt-20 lg:mt-24">
        {/* Hero Section */}
        <section className="flex flex-col items-center justify-center text-center p-4 lg:p-12">
          <h1 className="text-5xl font-extrabold text-white mb-4">{t.title}</h1>
          <p className="text-2xl font-medium text-white mb-8">{t.subtitle}</p>
          <p className="text-xl font-medium text-white mb-12">{t.experience}</p>
          <Slider {...settings} ref={sliderRef}>
            {serverOptions.map((server) => (
              <ServerCard key={server.name} server={server} t={t} />
            ))}
          </Slider>
        </section>

        {/* About Section */}
        <section className="p-4 lg:p-12" ref={aboutRef}>
          <h2 className="text-4xl font-extrabold text-white text-center mb-8">{t.about}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
            <div className="flex flex-col gap-4">
              <p className="text-xl font-medium text-white">{t.aboutEliIPTV}</p>
              <p className="text-lg font-medium text-white">{t.aboutContent1}</p>
              <p className="text-lg font-medium text-white">{t.aboutContent2}</p>
            </div>
            <div className="flex flex-col gap-4">
              <p className="text-lg font-medium text-white">{t.aboutContent3}</p>
              <p className="text-lg font-medium text-white">{t.aboutContent4}</p>
              <p className="text-lg font-medium text-white">{t.aboutContent5}</p>
            </div>
          </div>
        </section>

        {/* Additional Features Section */}
        <section className="p-4 lg:p-12 bg-black/20">
          <h2 className="text-4xl font-extrabold text-white text-center mb-8">{t.additionalFeatures}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-black/20 border-orange-500">
              <CardContent className="p-6 text-center">
                <div className="flex justify-center items-center mb-4">
                  <CheckCircle className="w-12 h-12 text-orange-500" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">{t.moneyBackGuarantee}</h2>
                <p className="text-3xl font-bold text-orange-500">7</p>
              </CardContent>
            </Card>
            <Card className="bg-black/20 border-orange-500">
              <CardContent className="p-6 text-center">
                <div className="flex justify-center items-center mb-4">
                  <Users className="w-12 h-12 text-orange-500" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">{t.clients}</h2>
                <p className="text-3xl font-bold text-orange-500">+1000</p>
              </CardContent>
            </Card>
            <Card className="bg-black/20 border-orange-500">
              <CardContent className="p-6 text-center">
                <div className="flex justify-center items-center mb-4">
                  <WhatsappIcon className="w-12 h-12 text-orange-500" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">{t.support}</h2>
                <p className="text-3xl font-bold text-orange-500">24/7</p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="p-4 lg:p-12" ref={receiveRef}>
          <h2 className="text-4xl font-extrabold text-white text-center mb-8">{t.faq}</h2>
          <div className="flex flex-col gap-8">
            <div className="flex flex-col gap-4">
              <h3 className="text-2xl font-bold text-white">{t.receiveSubscription}</h3>
              <p className="text-lg font-medium text-white">{t.receiveAnswer}</p>
            </div>
            <div className="flex flex-col gap-4">
              <h3 className="text-2xl font-bold text-white">{t.supportedDevices}</h3>
              <p className="text-lg font-medium text-white">{t.supportedDevicesAnswer}</p>
            </div>
            <div className="flex flex-col gap-4">
              <h3 className="text-2xl font-bold text-white">{t.connections}</h3>
              <p className="text-lg font-medium text-white">{t.connectionsAnswer}</p>
            </div>
            <div className="flex flex-col gap-4" ref={adultContentRef}>
              <h3 className="text-2xl font-bold text-white">{t.adultContent}</h3>
              <p className="text-lg font-medium text-white">{t.adultContentAnswer}</p>
            </div>
            <div className="flex flex-col gap-4" ref={internetSpeedRef}>
              <h3 className="text-2xl font-bold text-white">{t.internetSpeed}</h3>
              <p className="text-lg font-medium text-white">{t.internetSpeedAnswer}</p>
            </div>
            <div className="flex flex-col gap-4">
              <h3 className="text-2xl font-bold text-white">{t.refund}</h3>
              <p className="text-lg font-medium text-white">{t.refundAnswer}</p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="p-4 lg:p-12" ref={contactRef}>
          <h2 className="text-4xl font-extrabold text-white text-center mb-8">{t.contact}</h2>
          <div className="flex flex-col items-center justify-center">
            <a
              href="https://wa.me/33666959488"
              target="_blank"
              rel="noopener noreferrer"
              className="text-3xl font-bold text-white mb-4"
            >
              {t.contactUs}
            </a>
          </div>
        </section>

        {/* Footer */}
        <footer className="mt-12 p-4 lg:p-12 text-center text-white">
          <p>{t.footer}</p>
        </footer>
      </main>
    </div>
  )
}

