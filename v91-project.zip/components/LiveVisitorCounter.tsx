"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Tv } from "lucide-react"

export function LiveVisitorCounter() {
  const [visitorCount, setVisitorCount] = useState(0)

  useEffect(() => {
    const visitorCounts = [2, 6, 1, 3, 6, 5, 8, 1, 1, 5]
    let index = 0

    // Set initial count
    setVisitorCount(visitorCounts[0])

    // Simulate live updates
    const interval = setInterval(() => {
      index = (index + 1) % visitorCounts.length
      setVisitorCount(visitorCounts[index])
    }, 27000) // Update every 27 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="bg-black/20 border-orange-500">
      <CardContent className="p-6 text-center">
        <Tv className="w-12 h-12 mx-auto mb-4 text-orange-500" />
        <h3 className="text-3xl font-bold text-orange-500 mb-4">Best Server</h3>
        <div className="flex justify-between">
          <div className="flex flex-col items-start">
            <span className="text-base text-white mb-2">Trex</span>
            <span className="text-base text-white mb-2">Strong8k</span>
            <span className="text-base text-white mb-2">Tivione</span>
            <span className="text-base text-white">Magnum</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-base text-white mb-2">Dino</span>
            <span className="text-base text-white mb-2">Diamond</span>
            <span className="text-base text-white mb-2">4Kott</span>
            <span className="text-base text-white">Cobra</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-base text-white mb-2">Livego</span>
            <span className="text-base text-white mb-2">Crystal</span>
            <span className="text-base text-white mb-2">Lion</span>
            <span className="text-base text-white">Mega</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

