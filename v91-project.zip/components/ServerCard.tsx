import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Sparkles, CreditCard, ShoppingCart } from "lucide-react"

interface ServerCardProps {
  server: { name: string; price: string }
  t: {
    days: string
    buyWithStripe: string
    payWithPaypal: string
  }
}

export function ServerCard({ server, t }: ServerCardProps) {
  return (
    <Card className="bg-black/20 border-orange-500 max-w-md mx-auto">
      <CardContent className="p-6">
        <Sparkles className="w-12 h-12 mx-auto mb-4 text-orange-500" />
        <h3 className="text-2xl font-bold text-white mb-4">{server.name}</h3>
        <p className="text-xl font-bold text-white mb-4">365 {t.days}</p>
        <p className="text-5xl font-bold text-orange-500 mb-4">{server.price}</p>
        <p className="text-lg font-semibold text-white mb-4">HD/4K/8K IPTV</p>
        <ul className="text-white text-center mb-6 list-none">
          {[
            "+30.000 Channels",
            "+100.000 Vod",
            "+10.000 Series",
            "Watch Channels",
            "7 Days money back",
            "Whatsapp support",
            "Fast",
            "Support All Devices",
          ].map((feature, index) => (
            <li key={index} className="flex items-center justify-center">
              <span className="mr-2">✔</span> {feature}
            </li>
          ))}
        </ul>
        <div className="flex flex-col gap-4">
          <a href="https://buy.stripe.com/v91example" target="_blank" rel="noopener noreferrer">
            <Button
              variant="outline"
              className="w-full border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white"
            >
              <CreditCard className="w-5 h-5 mr-2" />
              {t.buyWithStripe}
            </Button>
          </a>
          <a href="https://www.paypal.me/v91example" target="_blank" rel="noopener noreferrer">
            <Button className="w-full bg-orange-600 hover:bg-orange-700">
              <ShoppingCart className="w-5 h-5 mr-2" />
              {t.payWithPaypal}
            </Button>
          </a>
        </div>
      </CardContent>
    </Card>
  )
}

