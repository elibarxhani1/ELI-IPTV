import { useState } from "react"
import { ChevronDown } from "lucide-react"

const languages = [
  { code: "en", name: "English" },
  { code: "fr", name: "Français" },
  { code: "es", name: "Español" },
  { code: "ar", name: "العربية" },
  { code: "sq", name: "Shqip" },
  { code: "de", name: "Deutsch" },
]

interface LanguageSelectorProps {
  onLanguageChange: (lang: string) => void
  currentLanguage: string
}

export function LanguageSelector({ onLanguageChange, currentLanguage }: LanguageSelectorProps) {
  const [isOpen, setIsOpen] = useState(false)
  const selectedLanguage = languages.find((lang) => lang.code === currentLanguage) || languages[0]

  const handleLanguageSelect = (lang: (typeof languages)[0]) => {
    onLanguageChange(lang.code)
    setIsOpen(false)
  }

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 bg-black/50 text-white px-4 py-2 rounded-md"
      >
        <span>{selectedLanguage.name}</span>
        <ChevronDown className="w-4 h-4" />
      </button>
      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-48 bg-black/80 rounded-md shadow-lg">
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => handleLanguageSelect(lang)}
              className="block w-full text-left px-4 py-2 text-white hover:bg-pink-500/20"
            >
              {lang.name}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

